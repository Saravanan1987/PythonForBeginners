print('Executable directories - Demo')
